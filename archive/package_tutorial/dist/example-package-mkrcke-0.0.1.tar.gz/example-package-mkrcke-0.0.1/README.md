# strutopy
A Python implementation for Structural Topic Modeling (Roberts et al., 2014) 
